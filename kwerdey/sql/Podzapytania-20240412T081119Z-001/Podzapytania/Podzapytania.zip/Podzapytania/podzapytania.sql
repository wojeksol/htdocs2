-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 19 Wrz 2019, 22:59
-- Wersja serwera: 10.1.37-MariaDB
-- Wersja PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `podzapytania`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `dzial`
--

CREATE TABLE `dzial` (
  `id_dzial` char(5) COLLATE utf8_polish_ci NOT NULL,
  `nazwa` varchar(40) COLLATE utf8_polish_ci DEFAULT NULL,
  `lokalizacja` varchar(40) COLLATE utf8_polish_ci DEFAULT NULL,
  `kierownik` char(4) COLLATE utf8_polish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `dzial`
--

INSERT INTO `dzial` (`id_dzial`, `nazwa`, `lokalizacja`, `kierownik`) VALUES
('PD303', 'Produkcyjny', 'Mysiecko', '110'),
('PK101', 'Projektowy', 'Mysieko', '101'),
('PR202', 'Promocji', 'Mysieoczko', '111'),
('PZ404', 'Zaopatrzenia', 'Myszków', NULL),
('PZ505', 'Zbytu', 'Maszków', NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pracownicy`
--

CREATE TABLE `pracownicy` (
  `id` char(4) COLLATE utf8_polish_ci NOT NULL,
  `nazwisko` varchar(40) COLLATE utf8_polish_ci DEFAULT NULL,
  `imie` varchar(40) COLLATE utf8_polish_ci DEFAULT NULL,
  `dzial` char(5) COLLATE utf8_polish_ci DEFAULT NULL,
  `stanowisko` varchar(40) COLLATE utf8_polish_ci DEFAULT NULL,
  `pobory` decimal(6,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `pracownicy`
--

INSERT INTO `pracownicy` (`id`, `nazwisko`, `imie`, `dzial`, `stanowisko`, `pobory`) VALUES
('101', 'Kowalczyk', 'Amadeusz', 'PK101', 'kierownik', '1000.00'),
('1010', 'Kawula', 'Alojzy', 'PK101', 'robotnik', '2500.00'),
('1011', 'Kowalowski', 'Alojzy', 'PK101', 'robotnik', '2500.00'),
('102', 'Janiak', 'Jerzy', 'PK101', 'analityk', '6000.00'),
('110', 'Kowalik', 'Artur', 'PD303', 'kierownik', '1500.00'),
('1100', 'Kowal', ' ', 'PD303', 'robotnik', '1500.00'),
('1101', 'Kowalski', 'Antoni', 'PD303', 'robotnik', '4500.00'),
('111', 'Kowalczuk', ' ', 'PR202', 'kierownik', '2500.00'),
('1110', 'Kowalewski', ' ', 'PR202', 'robotnik', '3500.00');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `dzial`
--
ALTER TABLE `dzial`
  ADD PRIMARY KEY (`id_dzial`);

--
-- Indeksy dla tabeli `pracownicy`
--
ALTER TABLE `pracownicy`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
