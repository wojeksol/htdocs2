-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 19 Wrz 2019, 22:59
-- Wersja serwera: 10.1.37-MariaDB
-- Wersja PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `podzapytania2`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `dzial`
--

CREATE TABLE `dzial` (
  `id` int(11) NOT NULL,
  `nazwa` varchar(40) COLLATE utf8_polish_ci DEFAULT NULL,
  `lokalizacja` varchar(40) COLLATE utf8_polish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `dzial`
--

INSERT INTO `dzial` (`id`, `nazwa`, `lokalizacja`) VALUES
(1001, 'FINANSE', 'SYDNEY'),
(2001, 'AUDYT', 'MELBOURNE'),
(3001, 'MARKETING', 'PERTH'),
(4001, 'PRODUKCJA', 'BRISBANE');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pobory`
--

CREATE TABLE `pobory` (
  `id` int(11) DEFAULT NULL,
  `min` int(11) DEFAULT NULL,
  `max` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `pobory`
--

INSERT INTO `pobory` (`id`, `min`, `max`) VALUES
(1, 800, 1300),
(2, 1301, 1500),
(3, 1501, 2100),
(4, 2101, 3100),
(5, 3101, 9999);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pracownicy`
--

CREATE TABLE `pracownicy` (
  `id` int(11) NOT NULL,
  `nazwisko` varchar(40) COLLATE utf8_polish_ci DEFAULT NULL,
  `stanowisko` varchar(40) COLLATE utf8_polish_ci DEFAULT NULL,
  `id_kierownika` int(11) DEFAULT NULL,
  `data_zatrudnienia` date DEFAULT NULL,
  `placa` decimal(6,2) DEFAULT NULL,
  `premia` decimal(6,2) DEFAULT NULL,
  `id_dzialu` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `pracownicy`
--

INSERT INTO `pracownicy` (`id`, `nazwisko`, `stanowisko`, `id_kierownika`, `data_zatrudnienia`, `placa`, `premia`, `id_dzialu`) VALUES
(63679, 'SANDRINE', 'URZĘDZNIK', 69062, '1990-12-18', '900.00', NULL, 2001),
(64989, 'ADELYN', 'SPRZEDAWCA', 66928, '1991-02-20', '1700.00', '400.00', 3001),
(65271, 'WADE', 'SPRZEDAWCA', 66928, '1991-02-22', '1350.00', '600.00', 3001),
(65646, 'JONAS', 'KIEROWNIK', 68319, '1991-04-02', '2957.00', NULL, 2001),
(66564, 'MADDEN', 'SPRZEDAWCA', 66928, '1991-09-28', '1350.00', '1500.00', 3001),
(66928, 'BLAZE', 'KIEROWNIK', 68319, '1991-05-01', '2750.00', NULL, 3001),
(67832, 'CLARE', 'KIEROWNIK', 68319, '1991-06-09', '2550.00', NULL, 1001),
(67858, 'SCARLET', 'ANALITYK', 65646, '1997-04-19', '3100.00', NULL, 2001),
(68319, 'KAYLING', 'DYREKTOR', NULL, '1991-11-18', '6000.00', NULL, 1001),
(68454, 'TUCKER', 'SPRZEDAWCA', 66928, '1991-09-08', '1600.00', '0.00', 3001),
(68736, 'ADNRES', 'URZĘDZNIK', 67858, '1997-05-23', '1200.00', NULL, 2001),
(69000, 'JULIUS', 'URZĘDZNIK', 66928, '1991-12-03', '1050.00', NULL, 3001),
(69062, 'FRANK', 'ANALITYK', 65646, '1991-12-03', '3100.00', NULL, 2001),
(69324, 'MARKER', 'URZĘDZNIK', 67832, '1992-01-23', '1400.00', NULL, 1001);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `dzial`
--
ALTER TABLE `dzial`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `pracownicy`
--
ALTER TABLE `pracownicy`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
