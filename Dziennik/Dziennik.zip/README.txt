loginy i hasła dla uczniów są u01, u02, ..., u256 itp. (uczniów jest 500)
loginy i hasła dla  nauczycieli to n01,n02,.., n100 itp. (nauczucieli jest 100)

Nauczyciel może dodać oceny, frekwencje i uwagi.

uczeń może zobaczyc oneny, frekwencje i uwagi (tylko swoje)

uczeń i nauczyciel mogą wysłać wiadomości